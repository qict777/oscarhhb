<?php
/**
 * es_es
 * 
 * @since 1.0
 * @package if
 * @subpackage plugin.pager.lang
 */
$message["pager_prev"] = "Anterior";
$message["pager_next"] = "Siguiente";
$message["pager_first"] = "Primera";
$message["pager_last"] = "&Uacute;ltima";
$message["pager_input_pageno"] = "Comenzar desde:";
$message["pager_current_pageno"] = "Actual: %d ";
$message["pager_total_page"] = "Total: %d ";

?>